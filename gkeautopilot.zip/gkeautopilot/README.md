# gkeautopilot


test

123



snapmirror delete -source-path -destination-path


 vserver peer delete -vserver -peer-vserver -force 


 vol clone split start -vserver amit -flexclone venky_clone_1035 